cd /go/src/github.com/keshu12345/truecaller
echo "additional flags $FLAGS"
echo "config dir is $CONFIG_PATH "
echo "---------------------- starting application -----------------"
./maching-prefixes
