package fillreturns

func hello[T any]() int {
	return
}
