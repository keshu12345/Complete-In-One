---
name: Having trouble getting started?
about: Please contact us at support@bugsnag.com for assistance with integrating Bugsnag
  into your application.
title: ''
labels: ''
assignees: ''

---
Please checkout our [documentation](https://docs.bugsnag.com/platforms/go/) for guides, references and tutorials.

If you have questions about your integration please contact us at [support@bugsnag.com](mailto:support@bugsnag.com).

Alternatively, view additional options at [support.md](../SUPPORT.md).