### Expected behavior
*[Insert details on expected behaviour]*

### Observed behavior
*[Insert details on observed behaviour]*

### Steps to reproduce
*[Insert reproduction steps (if known)]*

### Version
*[Insert version information]*

### Additional information
*[Insert any additional information]*

#### Can't comment on Issues?
Some users have been unable to comment on Github issues when an [adblocker extension is enabled](https://docs.bugsnag.com/platforms/browsers/faq/#is-bugsnag-blocked-by-ad-blockers).
We recommend temporarily disabling the extension, or if that fails, contacting support@bugsnag.com.
