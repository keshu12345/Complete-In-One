package ini

import (
	// internal/ini module was carved out of this module
	_ "github.com/aws/aws-sdk-go-v2"
)
