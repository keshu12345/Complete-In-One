package xml

const (
	leftAngleBracket  = '<'
	rightAngleBracket = '>'
	forwardSlash      = '/'
	colon             = ':'
	equals            = '='
	quote             = '"'
)
