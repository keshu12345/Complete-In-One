// DO NOT EDIT
package corehandlers

const isAwsInternal = ""