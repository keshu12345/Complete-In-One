# v3/integrations/nrpq [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/v3/integrations/nrpq?status.svg)](https://godoc.org/github.com/newrelic/go-agent/v3/integrations/nrpq)

Package `nrpq` instruments https://github.com/lib/pq.

```go
import "github.com/newrelic/go-agent/v3/integrations/nrpq"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/v3/integrations/nrpq).
