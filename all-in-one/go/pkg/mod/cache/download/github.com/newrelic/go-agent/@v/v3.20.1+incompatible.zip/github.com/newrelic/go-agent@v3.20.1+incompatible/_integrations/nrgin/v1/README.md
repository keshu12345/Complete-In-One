# _integrations/nrgin/v1 [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrgin/v1?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrgin/v1)

Package `nrgin` instruments https://github.com/gin-gonic/gin applications.

```go
import "github.com/newrelic/go-agent/_integrations/nrgin/v1"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrgin/v1).
