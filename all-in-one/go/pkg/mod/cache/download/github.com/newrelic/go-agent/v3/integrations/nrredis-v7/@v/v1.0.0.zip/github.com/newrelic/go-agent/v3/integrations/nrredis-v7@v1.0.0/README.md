# v3/integrations/nrredis-v7 [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/v3/integrations/nrredis-v7?status.svg)](https://godoc.org/github.com/newrelic/go-agent/v3/integrations/nrredis-v7)

Package `nrredis` instruments `"github.com/go-redis/redis/v7"`.

```go
import nrredis "github.com/newrelic/go-agent/v3/integrations/nrredis-v7"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/v3/integrations/nrredis-v7).
