# _integrations/nrb3 [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrb3?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrb3)

Package `nrb3` supports adding B3 headers to outgoing requests.

```go
import "github.com/newrelic/go-agent/_integrations/nrb3"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrb3).
