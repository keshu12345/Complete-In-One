# v3/integrations/nrgin [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/v3/integrations/nrgin?status.svg)](https://godoc.org/github.com/newrelic/go-agent/v3/integrations/nrgin)

Package `nrgin` instruments https://github.com/gin-gonic/gin applications.

```go
import "github.com/newrelic/go-agent/v3/integrations/nrgin"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/v3/integrations/nrgin).
