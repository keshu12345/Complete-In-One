# _integrations/nrawssdk [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrawssdk?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrawssdk)

Integrations for AWS SDKs versions 1 and 2.
