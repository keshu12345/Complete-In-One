# _integrations/nrzap [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrzap?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrzap)

Package `nrzap` supports https://github.com/uber-go/zap.

```go
import "github.com/newrelic/go-agent/_integrations/nrzap"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrzap).
