# _integrations/nrlogrus [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrlogrus?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrlogrus)

Package `nrlogrus` sends go-agent log messages to https://github.com/sirupsen/logrus.

```go
import "github.com/newrelic/go-agent/_integrations/nrlogrus"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrlogrus).
