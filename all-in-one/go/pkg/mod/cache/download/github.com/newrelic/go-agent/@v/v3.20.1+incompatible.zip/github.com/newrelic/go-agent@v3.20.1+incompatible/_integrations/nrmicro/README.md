# _integrations/nrmicro [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrmicro?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrmicro)

Package `nrmicro` instruments https://github.com/micro/go-micro.

```go
import "github.com/newrelic/go-agent/_integrations/nrmicro"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrmicro).
