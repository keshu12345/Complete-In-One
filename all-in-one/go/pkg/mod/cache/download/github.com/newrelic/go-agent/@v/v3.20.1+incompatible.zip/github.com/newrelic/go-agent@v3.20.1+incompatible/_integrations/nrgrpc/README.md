# _integrations/nrgrpc [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrgrpc?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrgrpc)

Package `nrgrpc` instruments https://github.com/grpc/grpc-go.

```go
import "github.com/newrelic/go-agent/_integrations/nrgrpc"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrgrpc).
