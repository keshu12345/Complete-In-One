Release notes are now available in our documentation at ([elastic.co](https://www.elastic.co/guide/en/apm/agent/go/current/release-notes.html))
