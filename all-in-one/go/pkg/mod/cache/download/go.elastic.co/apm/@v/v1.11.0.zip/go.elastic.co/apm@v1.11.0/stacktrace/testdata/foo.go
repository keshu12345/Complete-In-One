package testdata

// Foo does foo.
func Foo() {
	panic("context!")
}
